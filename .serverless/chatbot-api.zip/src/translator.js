"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const translate = new aws_sdk_1.default.Translate();
class Translator {
    translateMessage(message, sourceLang, targetLang) {
        return (new Promise((resolve, reject) => {
            const params = {
                Text: message,
                SourceLanguageCode: sourceLang,
                TargetLanguageCode: targetLang
            };
            translate.translateText(params, (err, data) => {
                if (err) {
                    console.log(err, err.stack);
                    reject(err);
                }
                else {
                    resolve(data);
                }
            });
        }));
    }
}
exports.default = Translator;
//# sourceMappingURL=translator.js.map